import ctypes
import time
import threading
import tkinter as tk
from tkinter import messagebox

class AutoClicker:
    def __init__(self, root):
        self.root = root
        self.root.title("AutoClicker")
        self.root.geometry("250x150")  
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)  

        self.autoclicker_running = False
        self.click_interval = 0.1  
        self.click_mode = "Continuous"  
        self.stop_hotkey = "<F6>"  

        self.create_widgets()

    def create_widgets(self):
        self.label_interval = tk.Label(self.root, text="Click interval (in seconds):")
        self.label_interval.grid(row=0, column=0, padx=10, pady=5, sticky="w")

        self.interval_entry = tk.Entry(self.root)
        self.interval_entry.grid(row=0, column=1, padx=10, pady=5, sticky="w")
        self.interval_entry.insert(0, str(self.click_interval))

        self.label_mode = tk.Label(self.root, text="Click mode:")
        self.label_mode.grid(row=1, column=0, padx=10, pady=5, sticky="w")

        self.mode_var = tk.StringVar()
        self.mode_var.set("Continuous")

        self.mode_menu = tk.OptionMenu(self.root, self.mode_var, "Continuous", "Single", "Cyclic")
        self.mode_menu.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        self.label_hotkey = tk.Label(self.root, text="Stop hotkey:")
        self.label_hotkey.grid(row=2, column=0, padx=10, pady=5, sticky="w")

        self.hotkey_entry = tk.Entry(self.root)
        self.hotkey_entry.grid(row=2, column=1, padx=10, pady=5, sticky="w")
        self.hotkey_entry.insert(0, self.stop_hotkey)

        self.settings_button = tk.Button(self.root, text="Settings", command=self.open_settings)
        self.settings_button.grid(row=0, column=2, padx=10, pady=5, sticky="w")

        self.start_button = tk.Button(self.root, text="Start", command=self.start_autoclicker)
        self.start_button.grid(row=4, column=0, padx=10, pady=5, sticky="w")

        self.stop_button = tk.Button(self.root, text="Stop", command=self.stop_autoclicker)
        self.stop_button.grid(row=4, column=1, padx=10, pady=5, sticky="w")

        self.root.bind("<Key>", self.key_pressed)  

    def click(self):
        ctypes.windll.user32.mouse_event(2, 0, 0, 0, 0)  
        ctypes.windll.user32.mouse_event(4, 0, 0, 0, 0)  

    def autoclicker(self):
        while self.autoclicker_running:
            if self.click_mode == "Single":
                self.click()
                self.stop_autoclicker()
            elif self.click_mode == "Continuous":
                self.click()
            elif self.click_mode == "Cyclic":
                self.click()
                time.sleep(self.click_interval)
            time.sleep(self.click_interval)

    def start_autoclicker(self):
        try:
            self.click_interval = float(self.interval_entry.get())
            self.click_mode = self.mode_var.get()
            self.stop_hotkey = self.hotkey_entry.get()
            if not self.autoclicker_running:
                self.autoclicker_running = True
                self.autoclicker_thread = threading.Thread(target=self.autoclicker)
                self.autoclicker_thread.start()
                messagebox.showinfo("Info", "AutoClicker started.")
            else:
                messagebox.showwarning("Warning", "AutoClicker is already running.")
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number for the click interval.")

    def stop_autoclicker(self):
        self.autoclicker_running = False
        if hasattr(self, 'autoclicker_thread'):
            self.autoclicker_thread.join()  
        messagebox.showinfo("Info", "AutoClicker stopped.")

    def open_settings(self):
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("200x150")

        label_stop_hotkey = tk.Label(settings_window, text="Stop hotkey:")
        label_stop_hotkey.grid(row=0, column=0, padx=10, pady=5, sticky="w")

        stop_hotkey_entry = tk.Entry(settings_window)
        stop_hotkey_entry.grid(row=0, column=1, padx=10, pady=5, sticky="w")
        stop_hotkey_entry.insert(0, self.stop_hotkey)

        label_other_settings = tk.Label(settings_window, text="Other settings:")
        label_other_settings.grid(row=1, column=0, padx=10, pady=5, sticky="w")

        other_settings_entry = tk.Entry(settings_window)
        other_settings_entry.grid(row=1, column=1, padx=10, pady=5, sticky="w")

    def on_closing(self):
        if self.autoclicker_running:
            self.stop_autoclicker()
        self.root.destroy()

    def key_pressed(self, event):
        if event.keysym == self.stop_hotkey and self.autoclicker_running:
            self.stop_autoclicker()

if __name__ == "__main__":
    root = tk.Tk()
    app = AutoClicker(root)
    root.mainloop()
